from tkinter import *

t = Tk()

t.title("Welcome to Tkinter app")

t.mainloop()